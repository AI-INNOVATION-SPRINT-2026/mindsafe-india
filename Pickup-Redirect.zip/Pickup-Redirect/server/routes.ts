import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth First
  await setupAuth(app);
  registerAuthRoutes(app);

  // Agent Routes
  app.get(api.agent.getProfile.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = (req.user as any).claims.sub;
    let profile = await storage.getAgentProfile(userId);
    if (!profile) {
      profile = await storage.createAgentProfile(userId);
    }
    res.json(profile);
  });

  app.post(api.agent.updateStatus.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = (req.user as any).claims.sub;
    const { status } = api.agent.updateStatus.input.parse(req.body);
    const profile = await storage.updateAgentStatus(userId, status);
    res.json(profile);
  });

  // Requests Routes
  app.get(api.requests.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const requests = await storage.getRequests();
    res.json(requests);
  });

  app.post(api.requests.accept.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = (req.user as any).claims.sub;
    const id = parseInt(req.params.id);
    
    // Check if exists
    const request = await storage.getRequest(id);
    if (!request) return res.status(404).json({ message: "Request not found" });

    const updated = await storage.updateRequestStatus(id, "Accepted", userId);
    res.json(updated);
  });

  app.post(api.requests.complete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const id = parseInt(req.params.id);
    
    const request = await storage.getRequest(id);
    if (!request) return res.status(404).json({ message: "Request not found" });

    const updated = await storage.updateRequestStatus(id, "Completed");
    res.json(updated);
  });

  // Chatbot Logic
  app.get(api.chat.history.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = (req.user as any).claims.sub;
    const messages = await storage.getMessages(userId);
    res.json(messages);
  });

  app.post(api.chat.sendMessage.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).send();
    const userId = (req.user as any).claims.sub;
    const { content } = api.chat.sendMessage.input.parse(req.body);

    // Save user message
    await storage.createMessage({
      userId,
      role: "user",
      content
    });

    // Fetch real-time data for context
    const allRequests = await storage.getRequests();
    const myRequests = await storage.getRequestsByAgent(userId);
    const pendingPickups = allRequests.filter(r => r.status === "Pending");
    const acceptedJobs = myRequests.filter(r => r.status === "Accepted");
    const completedJobs = myRequests.filter(r => r.status === "Completed");

    // Build context for AI
    const systemPrompt = `You are an AI assistant for Mind-Safe India, helping e-waste pickup agents with their work. You have access to real-time data about pickup requests and the agent's jobs.

Current Data:
- Pending pickup requests nearby: ${pendingPickups.length > 0 ? pendingPickups.map(p => `${p.location} (${p.deviceType}, ${p.distance})`).join("; ") : "None available"}
- Your accepted jobs: ${acceptedJobs.length > 0 ? acceptedJobs.map(j => `${j.location} for ${j.deviceType} at ${new Date(j.pickupTime).toLocaleString()}`).join("; ") : "None"}
- Completed jobs today: ${completedJobs.length}

Answer the agent's questions based on this data. Be helpful, concise, and eco-friendly in tone. If they ask about pickups, schedules, jobs, or locations, use the data above. For other questions, provide helpful guidance about e-waste recycling and the Mind-Safe platform.`;

    try {
      const chatHistory = await storage.getMessages(userId);
      const recentMessages = chatHistory.slice(-10).map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content
      }));

      const response = await openai.chat.completions.create({
        model: "gpt-5-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...recentMessages,
          { role: "user", content }
        ],
        max_completion_tokens: 500,
      });

      const responseText = response.choices[0]?.message?.content || "I apologize, I couldn't process that request. Please try again.";

      // Save assistant message
      const botMessage = await storage.createMessage({
        userId,
        role: "assistant",
        content: responseText
      });

      res.json({ response: responseText, message: botMessage });
    } catch (error) {
      console.error("OpenAI Error:", error);
      const fallbackText = "I'm having trouble connecting right now. Please try again in a moment.";
      const botMessage = await storage.createMessage({
        userId,
        role: "assistant",
        content: fallbackText
      });
      res.json({ response: fallbackText, message: botMessage });
    }
  });

  // Seed Data (if empty)
  const existing = await storage.getRequests();
  if (existing.length === 0) {
    const now = new Date();
    await storage.createRequest({
      location: "Andheri East, Mumbai",
      deviceType: "Mobile Phones (3)",
      pickupTime: new Date(now.getTime() + 3600000), // +1 hour
      distance: "2.5 km",
      status: "Pending"
    });
    await storage.createRequest({
      location: "Powai, Mumbai",
      deviceType: "Laptop (1)",
      pickupTime: new Date(now.getTime() + 7200000), // +2 hours
      distance: "5.1 km",
      status: "Pending"
    });
    await storage.createRequest({
      location: "Baner, Pune",
      deviceType: "Hard Drives (5)",
      pickupTime: new Date(now.getTime() + 86400000), // +1 day
      distance: "12 km",
      status: "Pending"
    });
    await storage.createRequest({
      location: "Vashi, Navi Mumbai",
      deviceType: "E-Waste Mix",
      pickupTime: new Date(now.getTime() + 172800000), // +2 days
      distance: "18 km",
      status: "Pending"
    });
  }

  return httpServer;
}
