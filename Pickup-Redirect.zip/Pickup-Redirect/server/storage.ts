import { db } from "./db";
import {
  requests,
  agentProfiles,
  messages,
  users,
  type Request,
  type AgentProfile,
  type Message,
  type InsertRequest,
  type InsertMessage
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // Agent Profile
  getAgentProfile(userId: string): Promise<AgentProfile | undefined>;
  createAgentProfile(userId: string): Promise<AgentProfile>;
  updateAgentStatus(userId: string, status: string): Promise<AgentProfile>;
  
  // Requests
  getRequests(): Promise<Request[]>;
  getRequestsByAgent(agentId: string): Promise<Request[]>;
  getRequest(id: number): Promise<Request | undefined>;
  createRequest(request: InsertRequest): Promise<Request>;
  updateRequestStatus(id: number, status: string, agentId?: string): Promise<Request>;
  
  // Messages
  getMessages(userId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class DatabaseStorage implements IStorage {
  // Agent Profile
  async getAgentProfile(userId: string): Promise<AgentProfile | undefined> {
    const [profile] = await db.select().from(agentProfiles).where(eq(agentProfiles.userId, userId));
    return profile;
  }

  async createAgentProfile(userId: string): Promise<AgentProfile> {
    const [profile] = await db.insert(agentProfiles).values({ userId }).returning();
    return profile;
  }

  async updateAgentStatus(userId: string, status: string): Promise<AgentProfile> {
    // Upsert profile if not exists
    let profile = await this.getAgentProfile(userId);
    if (!profile) {
      profile = await this.createAgentProfile(userId);
    }
    
    const [updated] = await db
      .update(agentProfiles)
      .set({ status })
      .where(eq(agentProfiles.userId, userId))
      .returning();
    return updated;
  }

  // Requests
  async getRequests(): Promise<Request[]> {
    return await db.select().from(requests).orderBy(desc(requests.pickupTime));
  }

  async getRequestsByAgent(agentId: string): Promise<Request[]> {
    return await db.select().from(requests).where(eq(requests.agentId, agentId)).orderBy(desc(requests.pickupTime));
  }

  async getRequest(id: number): Promise<Request | undefined> {
    const [req] = await db.select().from(requests).where(eq(requests.id, id));
    return req;
  }

  async createRequest(req: InsertRequest): Promise<Request> {
    const [newReq] = await db.insert(requests).values(req).returning();
    return newReq;
  }

  async updateRequestStatus(id: number, status: string, agentId?: string): Promise<Request> {
    const updates: any = { status };
    if (agentId) updates.agentId = agentId;
    
    const [updated] = await db
      .update(requests)
      .set(updates)
      .where(eq(requests.id, id))
      .returning();
    return updated;
  }

  // Messages
  async getMessages(userId: string): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.userId, userId)).orderBy(messages.timestamp);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [msg] = await db.insert(messages).values(message).returning();
    return msg;
  }
}

export const storage = new DatabaseStorage();
