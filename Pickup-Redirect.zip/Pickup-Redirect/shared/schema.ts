import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Export Auth Models
export * from "./models/auth";
import { users } from "./models/auth";

// Agent Profiles (Extending User Data)
export const agentProfiles = pgTable("agent_profiles", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  status: text("status").default("Available"), // Available, Busy, On the Way
  totalJobs: integer("total_jobs").default(0),
  distanceCovered: integer("distance_covered").default(0), // In km
});

// Pickup Requests
export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  location: text("location").notNull(),
  deviceType: text("device_type").notNull(),
  pickupTime: timestamp("pickup_time").notNull(),
  status: text("status").default("Pending"), // Pending, Accepted, Completed
  agentId: text("agent_id").references(() => users.id), // Assigned agent
  distance: text("distance").notNull(), // e.g. "2.5 km"
});

// Chat Messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  role: text("role").notNull(), // user, assistant
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Relations
export const agentProfilesRelations = relations(agentProfiles, ({ one }) => ({
  user: one(users, {
    fields: [agentProfiles.userId],
    references: [users.id],
  }),
}));

export const requestsRelations = relations(requests, ({ one }) => ({
  agent: one(users, {
    fields: [requests.agentId],
    references: [users.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  user: one(users, {
    fields: [messages.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertAgentProfileSchema = createInsertSchema(agentProfiles).omit({ id: true });
export const insertRequestSchema = createInsertSchema(requests).omit({ id: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, timestamp: true });

// Types
export type AgentProfile = typeof agentProfiles.$inferSelect;
export type Request = typeof requests.$inferSelect;
export type Message = typeof messages.$inferSelect;
