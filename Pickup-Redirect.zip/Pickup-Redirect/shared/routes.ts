import { z } from 'zod';
import { insertRequestSchema, insertMessageSchema, agentProfiles, requests, messages } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  // Agent Routes
  agent: {
    getProfile: {
      method: 'GET' as const,
      path: '/api/agent/profile',
      responses: {
        200: z.custom<typeof agentProfiles.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    updateStatus: {
      method: 'POST' as const,
      path: '/api/agent/status',
      input: z.object({ status: z.enum(['Available', 'Busy', 'On the Way']) }),
      responses: {
        200: z.custom<typeof agentProfiles.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },

  // Request Routes
  requests: {
    list: {
      method: 'GET' as const,
      path: '/api/requests',
      responses: {
        200: z.array(z.custom<typeof requests.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    accept: {
      method: 'POST' as const,
      path: '/api/requests/:id/accept',
      responses: {
        200: z.custom<typeof requests.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
    complete: {
      method: 'POST' as const,
      path: '/api/requests/:id/complete',
      responses: {
        200: z.custom<typeof requests.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    },
  },

  // Chat Routes
  chat: {
    history: {
      method: 'GET' as const,
      path: '/api/chat/history',
      responses: {
        200: z.array(z.custom<typeof messages.$inferSelect>()),
        401: errorSchemas.unauthorized,
      },
    },
    sendMessage: {
      method: 'POST' as const,
      path: '/api/chat/message',
      input: z.object({ content: z.string() }),
      responses: {
        200: z.object({
          response: z.string(),
          message: z.custom<typeof messages.$inferSelect>(), // The assistant message
        }),
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
