## Packages
framer-motion | Smooth page transitions and card animations
recharts | Visualization for agent statistics (distance, jobs)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Space Grotesk", "sans-serif"],
}
