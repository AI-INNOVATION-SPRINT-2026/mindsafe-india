import { Layout } from "@/components/layout";
import { Card } from "@/components/ui/card";
import { MapPin } from "lucide-react";

export default function MapPage() {
  return (
    <Layout>
      <div className="h-[calc(100vh-8rem)] flex flex-col">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900 font-display mb-6">Live Map</h1>
        
        <Card className="flex-1 relative overflow-hidden bg-emerald-50 border-emerald-100 shadow-inner flex items-center justify-center group">
          {/* Decorative Map Pattern Background */}
          <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80')] bg-cover bg-center grayscale" />
          
          {/* Fake Pins */}
          <div className="absolute top-1/4 left-1/4 animate-bounce duration-[2000ms]">
            <div className="relative group/pin cursor-pointer">
              <div className="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/30 text-white z-10 relative transform transition-transform group-hover/pin:scale-110">
                <MapPin className="w-6 h-6" />
              </div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-4 h-4 bg-emerald-500 rotate-45"></div>
              <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-full shadow-md text-xs font-bold opacity-0 group-hover/pin:opacity-100 transition-opacity whitespace-nowrap">
                Laptop Pickup (2km)
              </div>
            </div>
          </div>

          <div className="absolute top-1/2 right-1/3 animate-bounce duration-[2500ms]">
            <div className="relative group/pin cursor-pointer">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center shadow-lg shadow-orange-500/30 text-white z-10 relative transform transition-transform group-hover/pin:scale-110">
                <MapPin className="w-6 h-6" />
              </div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-4 h-4 bg-orange-500 rotate-45"></div>
              <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-white px-3 py-1 rounded-full shadow-md text-xs font-bold opacity-0 group-hover/pin:opacity-100 transition-opacity whitespace-nowrap">
                Mobile Batch (5km)
              </div>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm px-6 py-4 rounded-2xl shadow-xl text-center z-20 max-w-md mx-4">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Map Integration Placeholder</h3>
            <p className="text-gray-600 text-sm">
              In a production environment, this would integrate with Google Maps or Mapbox API to show real-time agent tracking and pickup locations.
            </p>
          </div>
        </Card>
      </div>
    </Layout>
  );
}
