import { useAgentProfile, useUpdateAgentStatus } from "@/hooks/use-agent";
import { useRequests } from "@/hooks/use-requests";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { MapPin, Truck, CheckCircle, Navigation, TrendingUp } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { cn } from "@/lib/utils";

const statsData = [
  { name: 'Mon', jobs: 4 },
  { name: 'Tue', jobs: 3 },
  { name: 'Wed', jobs: 5 },
  { name: 'Thu', jobs: 8 },
  { name: 'Fri', jobs: 6 },
  { name: 'Sat', jobs: 9 },
  { name: 'Sun', jobs: 7 },
];

export default function DashboardPage() {
  const { data: profile, isLoading: profileLoading } = useAgentProfile();
  const { data: requests, isLoading: requestsLoading } = useRequests();
  const { mutate: updateStatus, isPending: updatingStatus } = useUpdateAgentStatus();

  const handleStatusToggle = (checked: boolean) => {
    updateStatus(checked ? 'Available' : 'Busy');
  };

  const pendingRequests = requests?.filter(r => r.status === 'Pending') || [];
  const todayJobs = requests?.filter(r => r.status === 'Completed').length || 0;

  if (profileLoading || requestsLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 font-display">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Welcome back, here's your daily overview.</p>
        </div>
        
        <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-xl border shadow-sm">
          <span className={cn("text-sm font-medium", profile?.status === 'Available' ? "text-emerald-600" : "text-gray-500")}>
            {profile?.status}
          </span>
          <Switch 
            checked={profile?.status === 'Available'}
            onCheckedChange={handleStatusToggle}
            disabled={updatingStatus}
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-sm hover:shadow-md transition-shadow duration-200 border-l-4 border-l-emerald-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Today's Jobs</CardTitle>
            <CheckCircle className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todayJobs}</div>
            <p className="text-xs text-muted-foreground mt-1">+2 from yesterday</p>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm hover:shadow-md transition-shadow duration-200 border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Distance Covered</CardTitle>
            <Navigation className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{profile?.distanceCovered} km</div>
            <p className="text-xs text-muted-foreground mt-1">Total this week</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm hover:shadow-md transition-shadow duration-200 border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Requests</CardTitle>
            <Truck className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingRequests.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Requires action</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts & Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activity Chart */}
        <Card className="shadow-sm border-none bg-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Weekly Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={statsData}>
                  <defs>
                    <linearGradient id="colorJobs" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    cursor={{ stroke: '#10b981', strokeWidth: 1 }}
                  />
                  <Area type="monotone" dataKey="jobs" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorJobs)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Nearby Requests */}
        <Card className="shadow-sm border-none bg-white">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Nearby Pickups</CardTitle>
            <Button variant="outline" size="sm" className="h-8" asChild>
              <a href="/requests">View All</a>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingRequests.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No pending requests nearby.</div>
            ) : (
              pendingRequests.slice(0, 3).map((req) => (
                <div key={req.id} className="flex items-start justify-between p-4 rounded-xl bg-gray-50 border border-gray-100 hover:border-emerald-200 transition-colors">
                  <div className="flex gap-4">
                    <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 shrink-0">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{req.location}</h4>
                      <p className="text-sm text-gray-500 mt-1">{req.deviceType} • {new Date(req.pickupTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-gray-900">{req.distance}</div>
                    <Badge variant="secondary" className="mt-1 bg-yellow-100 text-yellow-800 hover:bg-yellow-100">{req.status}</Badge>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
