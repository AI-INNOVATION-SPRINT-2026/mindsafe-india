import { useRequests, useAcceptRequest, useCompleteRequest } from "@/hooks/use-requests";
import { Layout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Box, Calendar, ArrowRight, Check } from "lucide-react";
import { format } from "date-fns";

export default function RequestsPage() {
  const { data: requests, isLoading } = useRequests();
  const { mutate: acceptRequest, isPending: accepting } = useAcceptRequest();
  const { mutate: completeRequest, isPending: completing } = useCompleteRequest();

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </Layout>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100';
      case 'Accepted': return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      case 'Completed': return 'bg-green-100 text-green-800 hover:bg-green-100';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Layout>
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 font-display">Pickup Requests</h1>
          <p className="text-muted-foreground mt-1">Manage and track your assigned pickups.</p>
        </div>
      </div>

      <div className="grid gap-4">
        {requests?.map((req) => (
          <Card key={req.id} className="overflow-hidden border-none shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-0">
              <div className="flex flex-col md:flex-row">
                {/* Left Info Section */}
                <div className="flex-1 p-6 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getStatusColor(req.status || 'Pending')}>
                          {req.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground font-mono">ID: #{req.id}</span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900">{req.deviceType}</h3>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-emerald-600">{req.distance}</div>
                      <p className="text-xs text-muted-foreground">Estimated distance</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div className="flex items-center gap-3 text-sm text-gray-600">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        <MapPin className="w-4 h-4 text-gray-500" />
                      </div>
                      {req.location}
                    </div>
                    <div className="flex items-center gap-3 text-sm text-gray-600">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        <Calendar className="w-4 h-4 text-gray-500" />
                      </div>
                      {format(new Date(req.pickupTime), 'MMM dd, yyyy • hh:mm a')}
                    </div>
                  </div>
                </div>

                {/* Right Action Section */}
                <div className="bg-gray-50 p-6 flex items-center justify-center md:w-48 border-t md:border-t-0 md:border-l">
                  {req.status === 'Pending' && (
                    <Button 
                      className="w-full bg-emerald-600 hover:bg-emerald-700 shadow-lg shadow-emerald-200"
                      onClick={() => acceptRequest(req.id)}
                      disabled={accepting}
                    >
                      Accept Pickup
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                  {req.status === 'Accepted' && (
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => completeRequest(req.id)}
                      disabled={completing}
                    >
                      <Check className="w-4 h-4 mr-2" />
                      Complete
                    </Button>
                  )}
                  {req.status === 'Completed' && (
                    <div className="flex flex-col items-center text-emerald-600">
                      <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center mb-2">
                        <Check className="w-6 h-6" />
                      </div>
                      <span className="text-sm font-medium">Done</span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {requests?.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed">
            <Box className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No requests found</h3>
            <p className="text-gray-500">New pickup requests will appear here.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
