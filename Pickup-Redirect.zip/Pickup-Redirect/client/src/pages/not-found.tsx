import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-md text-center shadow-xl border-none">
        <CardContent className="pt-6 pb-8">
          <div className="mb-4 flex justify-center">
            <div className="bg-red-50 p-4 rounded-full">
              <AlertTriangle className="h-10 w-10 text-red-500" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2 font-display">Page Not Found</h1>
          <p className="text-gray-500 mb-6">
            The page you are looking for doesn't exist or has been moved.
          </p>
          <Link href="/">
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
              Return to Home
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
