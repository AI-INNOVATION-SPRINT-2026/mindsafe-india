import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Leaf, Recycle, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";

export default function LoginPage() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, setLocation]);

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-12 w-12 bg-gray-200 rounded-full mb-4"></div>
          <div className="h-4 w-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left Panel - Hero */}
      <div className="relative bg-emerald-900 overflow-hidden flex flex-col justify-between p-8 lg:p-12 text-white">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=2574&auto=format&fit=crop')] bg-cover bg-center opacity-20 mix-blend-overlay"></div>
        {/* Abstract Green Shapes */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-500/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-white/10 p-2.5 rounded-xl backdrop-blur-md">
              <Leaf className="w-8 h-8 text-emerald-300" />
            </div>
            <h1 className="text-2xl font-bold tracking-wide font-display">Mind Safe</h1>
          </div>
          
          <div className="space-y-6 max-w-lg">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-4xl lg:text-5xl font-bold leading-tight font-display"
            >
              Building a cleaner India, one pickup at a time.
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-emerald-100 text-lg"
            >
              The dedicated portal for e-waste collection agents. Manage requests, track your impact, and streamline logistics.
            </motion.p>
          </div>
        </div>

        <div className="relative z-10 grid grid-cols-3 gap-4 text-center mt-12">
          {[
            { icon: Recycle, label: "Eco-Friendly" },
            { icon: ShieldCheck, label: "Secure" },
            { icon: Leaf, label: "Sustainable" },
          ].map((item, i) => (
            <motion.div 
              key={item.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + (i * 0.1) }}
              className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10"
            >
              <item.icon className="w-6 h-6 mx-auto mb-2 text-emerald-300" />
              <p className="text-xs font-medium tracking-wide uppercase opacity-80">{item.label}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Right Panel - Login */}
      <div className="flex flex-col items-center justify-center p-8 lg:p-12 bg-white">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 font-display">Welcome Back</h2>
            <p className="mt-2 text-gray-600">Sign in to access your agent dashboard</p>
          </div>

          <div className="mt-8 space-y-6">
            <div className="space-y-4">
              <Button 
                onClick={handleLogin}
                className="w-full h-12 text-base font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-600/20 rounded-xl transition-all duration-200 hover:-translate-y-0.5"
              >
                Log in with Replit
              </Button>
            </div>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Secure Access Portal</span>
              </div>
            </div>

            <p className="text-center text-sm text-gray-500">
              By logging in, you agree to our Terms of Service and Privacy Policy.
            </p>

            <div className="pt-6 border-t border-gray-200 mt-6">
              <p className="text-center text-sm text-gray-600 mb-3">
                Looking to schedule a pickup instead?
              </p>
              <Button 
                variant="outline"
                onClick={() => window.location.href = "https://mind-sa--patilnagraj025.replit.app/pickup"}
                className="w-full h-11 text-base font-medium border-emerald-200 text-emerald-700 hover:bg-emerald-50 rounded-xl"
                data-testid="button-customer-redirect"
              >
                Go to Customer App
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
