import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useAgentProfile() {
  return useQuery({
    queryKey: [api.agent.getProfile.path],
    queryFn: async () => {
      const res = await fetch(api.agent.getProfile.path, { credentials: "include" });
      if (res.status === 401) throw new Error("Unauthorized");
      if (!res.ok) throw new Error("Failed to fetch profile");
      return api.agent.getProfile.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateAgentStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (status: 'Available' | 'Busy' | 'On the Way') => {
      const res = await fetch(api.agent.updateStatus.path, {
        method: api.agent.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update status");
      return api.agent.updateStatus.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.agent.getProfile.path] });
    },
  });
}
